package com.marisma.prueba3

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import android.util.Log
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnSiguiente = findViewById<AppCompatButton>(R.id.btnSiguiente)
        btnSiguiente.setOnClickListener {
            Log.i("Probando", "btnSiguiente Pulsado")
            val etName = findViewById<EditText>(R.id.etName)
            val nombre = etName.text.toString().trim()

            if (nombre.isEmpty()) {
                // El campo está vacío, muestra un cuadro de diálogo
                mostrarmensaje_alerta("Error", "Por favor, introduce un nombre.")
            } else {
                // El campo no está vacío, procede con la acción
                val intent = Intent(this, SiguienteActivity::class.java)
                intent.putExtra("Name", nombre)
                startActivity(intent)
            }
        }
    }
    private fun mostrarmensaje_alerta(title: String, message: String) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle(title)
        builder.setMessage(message)
        builder.setPositiveButton("OK") { dialog, _ ->
            dialog.dismiss()
        }
        val alertDialog = builder.create()
        alertDialog.show()
    }
}
