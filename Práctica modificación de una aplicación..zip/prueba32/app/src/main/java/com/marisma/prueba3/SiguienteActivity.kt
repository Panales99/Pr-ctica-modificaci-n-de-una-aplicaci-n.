package com.marisma.prueba3
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.CheckBox
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SiguienteActivity : AppCompatActivity() {
    private lateinit var checkboxRhaenyra: CheckBox
    private lateinit var checkboxAegon: CheckBox
    private lateinit var tvmensaje: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_siguiente)

        tvmensaje = findViewById(R.id.textViewMensaje)
        checkboxRhaenyra = findViewById(R.id.checkboxRhaenyra)
        checkboxAegon = findViewById(R.id.checkboxAegon)

        // Obtén el nombre del intent
        val nombre = intent.getStringExtra("Name")

        // Verifica si el nombre no es nulo antes de mostrar el mensaje
        if (nombre != null) {
            // Construye el mensaje específico y establece el texto en el TextView
            val mensaje = "SR $nombre, es el momento de que tomes una difícil elección... El rey Visersys ha muerto. Debes decidir quién será su sucesor como rey de los Andalos y los Primeros Hombres, Señor de los Siete Reinos y Protector del Reino. Para ello, debes decidir entre apoyar a..."
            tvmensaje.text = mensaje
        }
    }

    fun irAPantallaFinal(view: View) {
        // Verifica si al menos un checkbox está marcado
        if (checkboxRhaenyra.isChecked || checkboxAegon.isChecked) {
            // Al menos un checkbox está marcado, procede a PantallaFinalActivity
            val eleccion = obtenerEleccion()

            // Crea un Intent para abrir PantallaFinalActivity
            val intent = Intent(this, PantallaFinalActivity::class.java)

            // Agrega la elección como un extra en el Intent
            intent.putExtra("eleccion", eleccion)

            // Inicia la nueva actividad
            startActivity(intent)
        } else {
            // Ningún checkbox está marcado, muestra un mensaje de error
            tvmensaje.text = "Por favor, selecciona al menos una opción antes de continuar."
        }
    }

    // Función para obtener la elección del usuario según los checkboxes
    private fun obtenerEleccion(): String {
        // Verifica cuál de los checkboxes está marcado
        return when {
            checkboxRhaenyra.isChecked -> "Rhaenyra Targaryen"
            checkboxAegon.isChecked -> "Aegon Targaryen"
            else -> "Ninguno"
        }
    }
}
