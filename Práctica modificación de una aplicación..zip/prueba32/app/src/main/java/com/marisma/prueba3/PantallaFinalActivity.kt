package com.marisma.prueba3

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class PantallaFinalActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pantalla_final)

        // Obtén la información sobre la elección del usuario desde el intent
        val eleccion = intent.getStringExtra("eleccion")

        // Muestra el mensaje según la elección del usuario
        val mensaje = "Has elegido: $eleccion"
        val textViewMensajeFinal = findViewById<TextView>(R.id.textViewMensajeFinal)
        textViewMensajeFinal.text = mensaje

        // Configura el evento click para el botón de salir
        val buttonSalir = findViewById<Button>(R.id.buttonSalir)
        buttonSalir.setOnClickListener {
            // Cierra la actividad actual
            finish()
        }
    }
}
